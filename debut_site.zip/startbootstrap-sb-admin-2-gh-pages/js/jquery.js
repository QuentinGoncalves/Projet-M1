// Material Select Initialization
$(document).ready(function() {
$('.mdb-select').materialSelect();
});
